const mongoose = require('mongoose');
const Student = require('./models/student');

const connectDatabase = async () => {
    try {
        await mongoose.connect(
            'mongodb+srv://bzg:776759@cluster0.vjb0u.mongodb.net/myDatabase?retryWrites=true&w=majority'
        );
        console.log('Successfully connected to MongoDB.');
    } catch (error) {
        console.error('Failed to connect to MongoDB:', error.message);
        process.exit(1);
    }
};

const performCRUD = async () => {
    try {
        const studentData = [
            { name: 'Alex Johnson', age: 21, major: 'Biology', enrolled: true },
            { name: 'Emily Carter', age: 23, major: 'History', enrolled: false },
            { name: 'Michael Smith', age: 19, major: 'Physics', enrolled: true },
        ];
        await Student.insertMany(studentData);
        console.log('Student records added to the database.');

        const allStudents = await Student.find();
        console.log('All Students:', allStudents);

        const enrolledStudents = await Student.find({ enrolled: true });
        console.log('Enrolled Students:', enrolledStudents);

        const updatedStudent = await Student.findOneAndUpdate(
            { name: 'Emily Carter' },
            { major: 'Political Science', age: 24 },
            { new: true }
        );
        console.log('Updated Student:', updatedStudent);

        const deletionResult = await Student.deleteOne({ name: 'Michael Smith' });
        console.log('Deletion Result:', deletionResult);

        const remainingStudents = await Student.find();
        console.log('Remaining Students:', remainingStudents);
    } catch (error) {
        console.error('An error occurred during CRUD operations:', error.message);
    }
};

const runApp = async () => {
    await connectDatabase();
    await performCRUD();
    mongoose.connection.close();
};

runApp();
